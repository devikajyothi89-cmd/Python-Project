```python
import pandas as pd
df=pd.read_csv('Mental_Health_and_Social_Media_Balance_Dataset.csv')
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>User_ID</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Daily_Screen_Time(hrs)</th>
      <th>Sleep_Quality(1-10)</th>
      <th>Stress_Level(1-10)</th>
      <th>Days_Without_Social_Media</th>
      <th>Exercise_Frequency(week)</th>
      <th>Social_Media_Platform</th>
      <th>Happiness_Index(1-10)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>U001</td>
      <td>44</td>
      <td>Male</td>
      <td>3.1</td>
      <td>7.0</td>
      <td>6.0</td>
      <td>2.0</td>
      <td>5.0</td>
      <td>Facebook</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>U002</td>
      <td>30</td>
      <td>Other</td>
      <td>5.1</td>
      <td>7.0</td>
      <td>8.0</td>
      <td>5.0</td>
      <td>3.0</td>
      <td>LinkedIn</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>U003</td>
      <td>23</td>
      <td>Other</td>
      <td>7.4</td>
      <td>6.0</td>
      <td>7.0</td>
      <td>1.0</td>
      <td>3.0</td>
      <td>YouTube</td>
      <td>6.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>U004</td>
      <td>36</td>
      <td>Female</td>
      <td>5.7</td>
      <td>7.0</td>
      <td>8.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>TikTok</td>
      <td>8.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>U005</td>
      <td>34</td>
      <td>Female</td>
      <td>7.0</td>
      <td>4.0</td>
      <td>7.0</td>
      <td>5.0</td>
      <td>1.0</td>
      <td>X (Twitter)</td>
      <td>8.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Daily_Screen_Time(hrs)</th>
      <th>Sleep_Quality(1-10)</th>
      <th>Stress_Level(1-10)</th>
      <th>Days_Without_Social_Media</th>
      <th>Exercise_Frequency(week)</th>
      <th>Happiness_Index(1-10)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>500.000000</td>
      <td>500.000000</td>
      <td>500.000000</td>
      <td>500.000000</td>
      <td>500.000000</td>
      <td>500.000000</td>
      <td>500.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>32.988000</td>
      <td>5.530000</td>
      <td>6.304000</td>
      <td>6.618000</td>
      <td>3.134000</td>
      <td>2.448000</td>
      <td>8.376000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>9.960637</td>
      <td>1.734877</td>
      <td>1.529792</td>
      <td>1.542996</td>
      <td>1.858751</td>
      <td>1.428067</td>
      <td>1.524228</td>
    </tr>
    <tr>
      <th>min</th>
      <td>16.000000</td>
      <td>1.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>4.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>24.000000</td>
      <td>4.300000</td>
      <td>5.000000</td>
      <td>6.000000</td>
      <td>2.000000</td>
      <td>1.000000</td>
      <td>7.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>34.000000</td>
      <td>5.600000</td>
      <td>6.000000</td>
      <td>7.000000</td>
      <td>3.000000</td>
      <td>2.000000</td>
      <td>9.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>41.000000</td>
      <td>6.700000</td>
      <td>7.000000</td>
      <td>8.000000</td>
      <td>5.000000</td>
      <td>3.000000</td>
      <td>10.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>49.000000</td>
      <td>10.800000</td>
      <td>10.000000</td>
      <td>10.000000</td>
      <td>9.000000</td>
      <td>7.000000</td>
      <td>10.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.shape
```




    (500, 10)




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 500 entries, 0 to 499
    Data columns (total 10 columns):
     #   Column                     Non-Null Count  Dtype  
    ---  ------                     --------------  -----  
     0   User_ID                    500 non-null    object 
     1   Age                        500 non-null    int64  
     2   Gender                     500 non-null    object 
     3   Daily_Screen_Time(hrs)     500 non-null    float64
     4   Sleep_Quality(1-10)        500 non-null    float64
     5   Stress_Level(1-10)         500 non-null    float64
     6   Days_Without_Social_Media  500 non-null    float64
     7   Exercise_Frequency(week)   500 non-null    float64
     8   Social_Media_Platform      500 non-null    object 
     9   Happiness_Index(1-10)      500 non-null    float64
    dtypes: float64(6), int64(1), object(3)
    memory usage: 39.2+ KB
    


```python
column_to_avg = 'Daily_Screen_Time(hrs)'
avg_value = df[column_to_avg].mean()
print("Mean : ",avg_value)
median_val=df[column_to_avg].median()
print("Median : ",median_val)
std_val = df[column_to_avg].std()
print("Standard Deviation : ",std_val)
min_value = df[column_to_avg].min()
print("Minimum Value : ",min_value)
max_val = df[column_to_avg].max()
print("Maximum Value : ",max_val)
```

    Mean :  5.53
    Median :  5.6
    Standard Deviation :  1.734877401777543
    Minimum Value :  1.0
    Maximum Value :  10.8
    


```python
columns= [
    'Daily_Screen_Time(hrs)',
    'Sleep_Quality(1-10)',
    'Stress_Level(1-10)',
    'Days_Without_Social_Media',
    'Happiness_Index(1-10)',
    'Exercise_Frequency(week)'
]

print("\n--- Averages for multiple columns ---")
print(df[columns].mean())
```

    
    --- Averages for multiple columns ---
    Daily_Screen_Time(hrs)       5.530
    Sleep_Quality(1-10)          6.304
    Stress_Level(1-10)           6.618
    Days_Without_Social_Media    3.134
    Happiness_Index(1-10)        8.376
    Exercise_Frequency(week)     2.448
    dtype: float64
    


```python
columns= [
    'Daily_Screen_Time(hrs)',
    'Sleep_Quality(1-10)',
    'Stress_Level(1-10)',
    'Days_Without_Social_Media',
    'Happiness_Index(1-10)',
    'Exercise_Frequency(week)'
]

print("\n--- Median for multiple columns ---")
print(df[columns].median())
```

    
    --- Median for multiple columns ---
    Daily_Screen_Time(hrs)       5.6
    Sleep_Quality(1-10)          6.0
    Stress_Level(1-10)           7.0
    Days_Without_Social_Media    3.0
    Happiness_Index(1-10)        9.0
    Exercise_Frequency(week)     2.0
    dtype: float64
    


```python
columns= [
    'Daily_Screen_Time(hrs)',
    'Sleep_Quality(1-10)',
    'Stress_Level(1-10)',
    'Days_Without_Social_Media',
    'Happiness_Index(1-10)',
    'Exercise_Frequency(week)'
]

print("\n--- Standard deviation for multiple columns ---")
print(df[columns].std())
```

    
    --- Standard deviation for multiple columns ---
    Daily_Screen_Time(hrs)       1.734877
    Sleep_Quality(1-10)          1.529792
    Stress_Level(1-10)           1.542996
    Days_Without_Social_Media    1.858751
    Happiness_Index(1-10)        1.524228
    Exercise_Frequency(week)     1.428067
    dtype: float64
    


```python
columns= [
    'Daily_Screen_Time(hrs)',
    'Sleep_Quality(1-10)',
    'Stress_Level(1-10)',
    'Days_Without_Social_Media',
    'Happiness_Index(1-10)',
    'Exercise_Frequency(week)'
]

print("\n--- Minimum value for multiple columns ---")
print(df[columns].min())
```

    
    --- Minimum value for multiple columns ---
    Daily_Screen_Time(hrs)       1.0
    Sleep_Quality(1-10)          2.0
    Stress_Level(1-10)           2.0
    Days_Without_Social_Media    0.0
    Happiness_Index(1-10)        4.0
    Exercise_Frequency(week)     0.0
    dtype: float64
    


```python
columns= [
    'Daily_Screen_Time(hrs)',
    'Sleep_Quality(1-10)',
    'Stress_Level(1-10)',
    'Days_Without_Social_Media',
    'Happiness_Index(1-10)',
    'Exercise_Frequency(week)'
]

print("\n---Maximum value of multiple columns ---")
print(df[columns].max())
```

    
    ---Maximum value of multiple columns ---
    Daily_Screen_Time(hrs)       10.8
    Sleep_Quality(1-10)          10.0
    Stress_Level(1-10)           10.0
    Days_Without_Social_Media     9.0
    Happiness_Index(1-10)        10.0
    Exercise_Frequency(week)      7.0
    dtype: float64
    


```python
import matplotlib.pyplot as plt
import numpy as np
columns= ['Age', 'Daily_Screen_Time(hrs)', 'Sleep_Quality(1-10)', 
                'Stress_Level(1-10)', 'Days_Without_Social_Media', 
                'Exercise_Frequency(week)', 'Happiness_Index(1-10)']
numeric_df = df[columns]
corr_matrix = numeric_df.corr()
platform_happiness = df.groupby('Social_Media_Platform')['Happiness_Index(1-10)'].mean().sort_values()
fig = plt.figure(figsize=(18, 6))
# ------------------- BAR CHART -------------------
ax1 = plt.subplot(1, 3, 1)
bars = ax1.bar(platform_happiness.index, platform_happiness.values, 
               color=['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FECA57', '#DDA0DD'])
ax1.set_title('Average Happiness by Platform', fontsize=14, fontweight='bold')
ax1.set_ylabel('Happiness Index (1-10)')
ax1.set_xlabel('Social Media Platform')
ax1.set_ylim(0, 10)
ax1.grid(axis='y', linestyle='--', alpha=0.7)
plt.setp(ax1.get_xticklabels(), rotation=45, ha='right')
# Add value labels on top of bars
for bar in bars:
    height = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width()/2., height + 0.1,
             f'{height:.2f}', ha='center', va='bottom', fontsize=10)
# ------------------- SCATTER PLOT -------------------
ax2 = plt.subplot(1, 3, 2)
scatter = ax2.scatter(df['Daily_Screen_Time(hrs)'], df['Happiness_Index(1-10)'],
                      c=df['Stress_Level(1-10)'], cmap='RdYlGn_r', alpha=0.7, edgecolors='k', s=60)
ax2.set_title('Screen Time vs Happiness\n(Color = Stress Level)', fontsize=14, fontweight='bold')
ax2.set_xlabel('Daily Screen Time (hrs)')
ax2.set_ylabel('Happiness Index (1-10)')
ax2.grid(True, linestyle='--', alpha=0.5)
cbar = plt.colorbar(scatter, ax=ax2)
cbar.set_label('Stress Level (1-10)')

# ------------------- HEATMAP -------------------
ax3 = plt.subplot(1, 3, 3)
im = ax3.imshow(corr_matrix, cmap='coolwarm', vmin=-1, vmax=1)
for i in range(len(corr_matrix)):
    for j in range(len(corr_matrix)):
        text = ax3.text(j, i, f'{corr_matrix.iloc[i, j]:.2f}',
                       ha="center", va="center", color="black", fontsize=9)

ax3.set_title('Correlation Heatmap', fontsize=14, fontweight='bold')
ax3.set_xticks(np.arange(len(corr_matrix.columns)))
ax3.set_yticks(np.arange(len(corr_matrix.columns)))
ax3.set_xticklabels(corr_matrix.columns, rotation=45, ha='right')
ax3.set_yticklabels(corr_matrix.columns)
cbar = plt.colorbar(im, ax=ax3)
cbar.set_label('Correlation Coefficient')
plt.tight_layout()
plt.suptitle('Mental Health & Social Media: Key Visual Insights', 
             fontsize=18, fontweight='bold', y=1.05)
plt.show()
```


    
![png](output_10_0.png)
    



```python
#  IMPORT LIBRARIES
import numpy as np
import statsmodels.api as sm

#  LOAD DATA
df = pd.read_csv('data.csv')
print("Original shape:", df.shape)
print("Columns:", df.columns)

#  CLEANING
# Remove invalid prices
df = df[df['price'] > 0].copy()
print("After removing price <= 0:", df.shape)

# Drop non-predictive or redundant columns
cols_to_drop = ['date', 'street', 'country']
df = df.drop(columns=[col for col in cols_to_drop if col in df.columns])


# FEATURE ENGINEERING
# One-hot encode categorical columns
categorical_cols = ['city', 'statezip']
for col in categorical_cols:
    if col in df.columns:
        dummies = pd.get_dummies(df[col], prefix=col, drop_first=True)
        df = pd.concat([df.drop(col, axis=1), dummies], axis=1)

# Define X and y
X = df.drop('price', axis=1)
y = df['price']

print(f"X has {X.shape[1]} features before cleaning")

#  CRITICAL: CONVERT ALL FEATURES TO NUMERIC

# Force all columns to numeric (coerce errors → NaN)
X = X.apply(pd.to_numeric, errors='coerce')

# Drop any columns that became all NaN (shouldn't happen, but safe)
X = X.dropna(axis=1, how='all')

# Fill any remaining NaN with 0 (e.g., if yr_renovated had issues)
X = X.fillna(0)

# Ensure all are float (statsmodels likes this)
X = X.astype(float)

print(f"Final X shape: {X.shape}")
print("Data types in X:")
print(X.dtypes.value_counts())

#  ADD CONSTANT & TRAIN MODEL

X = sm.add_constant(X)  # Adds intercept

# Now train — this will NOT fail
model = sm.OLS(y, X).fit()

print(model.summary())

# RESULTS

print(f"\nR-squared: {model.rsquared:.3f}")
print(f"Adjusted R-squared: {model.rsquared_adj:.3f}")

# Top 10 positive coefficients
coef_df = pd.DataFrame({
    'Feature': model.params.index,
    'Coefficient': model.params.values,
    'P-value': model.pvalues.values
}).round(2)

print("\nTOP 10 PRICE-INCREASING FEATURES:")
display(coef_df.nlargest(10, 'Coefficient')[['Feature', 'Coefficient', 'P-value']])

print("\nTOP 10 PRICE-DECREASING FEATURES:")
display(coef_df.nsmallest(10, 'Coefficient')[['Feature', 'Coefficient', 'P-value']])
```

    Original shape: (4600, 18)
    Columns: Index(['date', 'price', 'bedrooms', 'bathrooms', 'sqft_living', 'sqft_lot',
           'floors', 'waterfront', 'view', 'condition', 'sqft_above',
           'sqft_basement', 'yr_built', 'yr_renovated', 'street', 'city',
           'statezip', 'country'],
          dtype='object')
    After removing price <= 0: (4551, 18)
    X has 131 features before cleaning
    Final X shape: (4551, 131)
    Data types in X:
    float64    131
    Name: count, dtype: int64
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:                  price   R-squared:                       0.328
    Model:                            OLS   Adj. R-squared:                  0.312
    Method:                 Least Squares   F-statistic:                     20.62
    Date:                Sun, 16 Nov 2025   Prob (F-statistic):          4.12e-303
    Time:                        10:19:35   Log-Likelihood:                -65822.
    No. Observations:                4551   AIC:                         1.319e+05
    Df Residuals:                    4445   BIC:                         1.325e+05
    Df Model:                         105                                         
    Covariance Type:            nonrobust                                         
    ============================================================================================
                                   coef    std err          t      P>|t|      [0.025      0.975]
    --------------------------------------------------------------------------------------------
    const                    -6.322e+05   8.08e+05     -0.783      0.434   -2.22e+06    9.51e+05
    bedrooms                 -3.022e+04   1.03e+04     -2.943      0.003   -5.04e+04   -1.01e+04
    bathrooms                 3.847e+04   1.65e+04      2.328      0.020    6069.809    7.09e+04
    sqft_living                126.9162      9.649     13.153      0.000     107.998     145.834
    sqft_lot                     0.0133      0.218      0.061      0.952      -0.415       0.441
    floors                   -7.609e+04   2.04e+04     -3.723      0.000   -1.16e+05    -3.6e+04
    waterfront                6.137e+05    9.5e+04      6.458      0.000    4.27e+05       8e+05
    view                      5.866e+04   1.09e+04      5.389      0.000    3.73e+04       8e+04
    condition                  3.44e+04   1.27e+04      2.700      0.007    9418.944    5.94e+04
    sqft_above                 122.9776     10.453     11.765      0.000     102.484     143.471
    sqft_basement                3.9387     13.792      0.286      0.775     -23.100      30.977
    yr_built                   227.6803    389.137      0.585      0.559    -535.222     990.582
    yr_renovated                 7.3707      8.280      0.890      0.373      -8.862      23.603
    city_Auburn               2.188e+04   2.18e+05      0.100      0.920   -4.06e+05     4.5e+05
    city_Beaux Arts Village  -2.286e+04   4.35e+05     -0.053      0.958   -8.75e+05     8.3e+05
    city_Bellevue             2.387e+05   1.35e+05      1.768      0.077    -2.6e+04    5.04e+05
    city_Black Diamond        6.403e+04   1.33e+05      0.480      0.631   -1.97e+05    3.26e+05
    city_Bothell              9.244e+04   2.58e+05      0.359      0.720   -4.13e+05    5.98e+05
    city_Burien               2.112e+05    1.9e+05      1.112      0.266   -1.61e+05    5.83e+05
    city_Carnation            5.426e+04   1.16e+05      0.467      0.640   -1.73e+05    2.82e+05
    city_Clyde Hill           4.264e+05   1.94e+05      2.192      0.028    4.51e+04    8.08e+05
    city_Covington             1.18e+05   1.59e+05      0.741      0.459   -1.94e+05     4.3e+05
    city_Des Moines            2.86e+05   2.52e+05      1.135      0.256   -2.08e+05     7.8e+05
    city_Duvall               4.522e+04   1.11e+05      0.408      0.683   -1.72e+05    2.62e+05
    city_Enumclaw            -1048.9687   1.14e+05     -0.009      0.993   -2.25e+05    2.23e+05
    city_Fall City            8.684e+04   1.27e+05      0.686      0.493   -1.61e+05    3.35e+05
    city_Federal Way         -3.841e+04   3.14e+05     -0.122      0.903   -6.54e+05    5.77e+05
    city_Inglewood-Finn Hill  1.191e+05   3.67e+05      0.324      0.746   -6.01e+05     8.4e+05
    city_Issaquah              1.55e+05   2.56e+05      0.605      0.545   -3.47e+05    6.57e+05
    city_Kenmore              5.339e+04   2.61e+05      0.205      0.838   -4.58e+05    5.65e+05
    city_Kent                 6.505e+04   1.43e+05      0.453      0.650   -2.16e+05    3.46e+05
    city_Kirkland             1.596e+05   1.59e+05      1.002      0.316   -1.53e+05    4.72e+05
    city_Lake Forest Park     1.035e+05   2.07e+05      0.501      0.617   -3.02e+05    5.09e+05
    city_Maple Valley         1.863e+04   1.07e+05      0.174      0.862   -1.92e+05    2.29e+05
    city_Medina               6.314e+05   1.27e+05      4.983      0.000    3.83e+05     8.8e+05
    city_Mercer Island        2.737e+05   1.08e+05      2.533      0.011    6.19e+04    4.86e+05
    city_Milton               5.691e+04   1.96e+05      0.291      0.771   -3.27e+05    4.41e+05
    city_Newcastle            1.438e+05   1.68e+05      0.855      0.393   -1.86e+05    4.74e+05
    city_Normandy Park        2.847e+05   2.28e+05      1.251      0.211   -1.61e+05    7.31e+05
    city_North Bend           4.787e+04    1.1e+05      0.436      0.663   -1.67e+05    2.63e+05
    city_Pacific              1.944e+04   1.42e+05      0.137      0.891   -2.58e+05    2.97e+05
    city_Preston              7.183e+04   1.96e+05      0.366      0.715   -3.13e+05    4.57e+05
    city_Ravensdale           4.142e+04   1.38e+05      0.301      0.764   -2.28e+05    3.11e+05
    city_Redmond              1.505e+05   2.79e+05      0.540      0.589   -3.96e+05    6.97e+05
    city_Renton               2.633e+04   1.53e+05      0.173      0.863   -2.73e+05    3.25e+05
    city_Sammamish            1.572e+05   2.02e+05      0.777      0.437   -2.39e+05    5.54e+05
    city_SeaTac               2.501e+05   2.11e+05      1.185      0.236   -1.64e+05    6.64e+05
    city_Seattle              2.428e+05   1.67e+05      1.451      0.147   -8.52e+04    5.71e+05
    city_Shoreline            1.455e+05   1.81e+05      0.805      0.421   -2.09e+05       5e+05
    city_Skykomish             5.12e+04   1.71e+05      0.299      0.765   -2.84e+05    3.86e+05
    city_Snoqualmie           4.607e+04   1.08e+05      0.425      0.671   -1.67e+05    2.59e+05
    city_Snoqualmie Pass      1.333e+05   2.57e+05      0.520      0.603    -3.7e+05    6.36e+05
    city_Tukwila              2.769e+05   1.95e+05      1.422      0.155   -1.05e+05    6.59e+05
    city_Vashon              -1.143e+04   1.14e+05     -0.100      0.920   -2.35e+05    2.12e+05
    city_Woodinville          1.134e+05   1.43e+05      0.795      0.427   -1.66e+05    3.93e+05
    city_Yarrow Point         2.136e+05   2.48e+05      0.862      0.389   -2.72e+05    6.99e+05
    statezip_WA 98002        -9859.6336   1.01e+05     -0.098      0.922   -2.07e+05    1.88e+05
    statezip_WA 98003         4.386e+04   2.44e+05      0.180      0.857   -4.34e+05    5.22e+05
    statezip_WA 98004         5.732e+05   1.18e+05      4.875      0.000    3.43e+05    8.04e+05
    statezip_WA 98005         1.174e+05   1.39e+05      0.846      0.398   -1.55e+05    3.89e+05
    statezip_WA 98006         7.319e+04   1.22e+05      0.598      0.550   -1.67e+05    3.13e+05
    statezip_WA 98007         7.329e+04   1.34e+05      0.549      0.583   -1.89e+05    3.35e+05
    statezip_WA 98008         1.887e+04    1.3e+05      0.145      0.885   -2.36e+05    2.74e+05
    statezip_WA 98010         6.403e+04   1.33e+05      0.480      0.631   -1.97e+05    3.26e+05
    statezip_WA 98011         4.735e+04   2.64e+05      0.179      0.858   -4.71e+05    5.65e+05
    statezip_WA 98014         5.426e+04   1.16e+05      0.467      0.640   -1.73e+05    2.82e+05
    statezip_WA 98019         4.522e+04   1.11e+05      0.408      0.683   -1.72e+05    2.62e+05
    statezip_WA 98022        -1048.9687   1.14e+05     -0.009      0.993   -2.25e+05    2.23e+05
    statezip_WA 98023         1.278e+04   2.39e+05      0.053      0.957   -4.56e+05    4.82e+05
    statezip_WA 98024         8.684e+04   1.27e+05      0.686      0.493   -1.61e+05    3.35e+05
    statezip_WA 98027         2.476e+04    2.3e+05      0.108      0.914   -4.26e+05    4.75e+05
    statezip_WA 98028         9.848e+04   2.58e+05      0.382      0.702   -4.07e+05    6.04e+05
    statezip_WA 98029         1.152e+05    2.3e+05      0.501      0.617   -3.36e+05    5.66e+05
    statezip_WA 98030        -4.814e+04   9.77e+04     -0.493      0.622    -2.4e+05    1.43e+05
    statezip_WA 98031         3.682e+05   9.05e+04      4.066      0.000    1.91e+05    5.46e+05
    statezip_WA 98032        -7.422e+04   1.14e+05     -0.652      0.514   -2.97e+05    1.49e+05
    statezip_WA 98033         2.204e+05   1.63e+05      1.350      0.177   -9.96e+04     5.4e+05
    statezip_WA 98034         5.836e+04   1.59e+05      0.366      0.714   -2.54e+05    3.71e+05
    statezip_WA 98038         1.863e+04   1.07e+05      0.174      0.862   -1.92e+05    2.29e+05
    statezip_WA 98039         6.314e+05   1.27e+05      4.983      0.000    3.83e+05     8.8e+05
    statezip_WA 98040         2.737e+05   1.08e+05      2.533      0.011    6.19e+04    4.86e+05
    statezip_WA 98042        -6.278e+04   8.54e+04     -0.735      0.462    -2.3e+05    1.05e+05
    statezip_WA 98045         4.787e+04    1.1e+05      0.436      0.663   -1.67e+05    2.63e+05
    statezip_WA 98047         1.944e+04   1.42e+05      0.137      0.891   -2.58e+05    2.97e+05
    statezip_WA 98050         7.183e+04   1.96e+05      0.366      0.715   -3.13e+05    4.57e+05
    statezip_WA 98051         4.142e+04   1.38e+05      0.301      0.764   -2.28e+05    3.11e+05
    statezip_WA 98052         1.312e+05   2.54e+05      0.517      0.605   -3.66e+05    6.29e+05
    statezip_WA 98053         6.903e+04   2.55e+05      0.271      0.786    -4.3e+05    5.68e+05
    statezip_WA 98055         4.306e+04   1.01e+05      0.428      0.668   -1.54e+05     2.4e+05
    statezip_WA 98056         6.537e+04   7.84e+04      0.834      0.404   -8.83e+04    2.19e+05
    statezip_WA 98057        -5206.3389   1.26e+05     -0.041      0.967   -2.52e+05    2.41e+05
    statezip_WA 98058         1.488e+04   7.85e+04      0.189      0.850   -1.39e+05    1.69e+05
    statezip_WA 98059         5.204e+04   7.58e+04      0.687      0.492   -9.66e+04    2.01e+05
    statezip_WA 98065         4.607e+04   1.08e+05      0.425      0.671   -1.67e+05    2.59e+05
    statezip_WA 98068         1.333e+05   2.57e+05      0.520      0.603    -3.7e+05    6.36e+05
    statezip_WA 98070        -1.143e+04   1.14e+05     -0.100      0.920   -2.35e+05    2.12e+05
    statezip_WA 98072         5.833e+04    8.3e+04      0.702      0.482   -1.04e+05    2.21e+05
    statezip_WA 98074          5.06e+04   1.63e+05      0.310      0.756   -2.69e+05     3.7e+05
    statezip_WA 98075         7.196e+04   1.63e+05      0.441      0.659   -2.48e+05    3.92e+05
    statezip_WA 98077         5.512e+04   8.49e+04      0.649      0.516   -1.11e+05    2.22e+05
    statezip_WA 98092        -4.434e+04   8.09e+04     -0.548      0.584   -2.03e+05    1.14e+05
    statezip_WA 98102         2.811e+05    1.1e+05      2.549      0.011    6.49e+04    4.97e+05
    statezip_WA 98103         1.523e+05    6.7e+04      2.272      0.023    2.09e+04    2.84e+05
    statezip_WA 98105          3.41e+05   8.62e+04      3.955      0.000    1.72e+05     5.1e+05
    statezip_WA 98106        -7.556e+04   7.85e+04     -0.962      0.336    -2.3e+05    7.84e+04
    statezip_WA 98107         1.668e+05   8.15e+04      2.047      0.041    7084.959    3.27e+05
    statezip_WA 98108        -7.629e+04   8.79e+04     -0.868      0.386   -2.49e+05    9.61e+04
    statezip_WA 98109         4.424e+05   1.01e+05      4.394      0.000    2.45e+05     6.4e+05
    statezip_WA 98112         4.318e+05   7.83e+04      5.516      0.000    2.78e+05    5.85e+05
    statezip_WA 98115         1.237e+05   6.81e+04      1.816      0.069   -9846.322    2.57e+05
    statezip_WA 98116         1.077e+05   7.94e+04      1.357      0.175   -4.79e+04    2.63e+05
    statezip_WA 98117         1.196e+05   6.78e+04      1.765      0.078   -1.32e+04    2.53e+05
    statezip_WA 98118        -4.521e+04   7.51e+04     -0.602      0.547   -1.92e+05    1.02e+05
    statezip_WA 98119         3.379e+05    8.6e+04      3.929      0.000    1.69e+05    5.07e+05
    statezip_WA 98122         1.526e+05   7.88e+04      1.936      0.053   -1903.737    3.07e+05
    statezip_WA 98125        -3.511e+04   7.34e+04     -0.478      0.632   -1.79e+05    1.09e+05
    statezip_WA 98126        -7474.5782   7.54e+04     -0.099      0.921   -1.55e+05     1.4e+05
    statezip_WA 98133        -6258.7793   7.77e+04     -0.081      0.936   -1.59e+05    1.46e+05
    statezip_WA 98136         5.206e+04    8.2e+04      0.635      0.525   -1.09e+05    2.13e+05
    statezip_WA 98144         1.006e+05   7.52e+04      1.338      0.181   -4.68e+04    2.48e+05
    statezip_WA 98146        -9.102e+04   8.08e+04     -1.127      0.260   -2.49e+05    6.74e+04
    statezip_WA 98148          -1.6e+05   1.53e+05     -1.047      0.295    -4.6e+05     1.4e+05
    statezip_WA 98155         2.614e+04   1.08e+05      0.243      0.808   -1.85e+05    2.37e+05
    statezip_WA 98166        -1.469e+05   1.25e+05     -1.174      0.240   -3.92e+05    9.84e+04
    statezip_WA 98168        -1.305e+05   8.36e+04     -1.560      0.119   -2.94e+05    3.35e+04
    statezip_WA 98177         8.675e+04    8.9e+04      0.975      0.330   -8.77e+04    2.61e+05
    statezip_WA 98178        -1.998e+05   8.52e+04     -2.345      0.019   -3.67e+05   -3.28e+04
    statezip_WA 98188        -2.341e+05   1.55e+05     -1.509      0.131   -5.38e+05       7e+04
    statezip_WA 98198        -2.929e+05   1.97e+05     -1.486      0.137   -6.79e+05    9.35e+04
    statezip_WA 98199         3.791e+05   7.85e+04      4.832      0.000    2.25e+05    5.33e+05
    statezip_WA 98288          5.12e+04   1.71e+05      0.299      0.765   -2.84e+05    3.86e+05
    statezip_WA 98354         5.691e+04   1.96e+05      0.291      0.771   -3.27e+05    4.41e+05
    ==============================================================================
    Omnibus:                    13638.124   Durbin-Watson:                   2.067
    Prob(Omnibus):                  0.000   Jarque-Bera (JB):        996101207.398
    Skew:                          42.990   Prob(JB):                         0.00
    Kurtosis:                    2293.330   Cond. No.                     1.11e+16
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
    [2] The smallest eigenvalue is 5.58e-20. This might indicate that there are
    strong multicollinearity problems or that the design matrix is singular.
    
    R-squared: 0.328
    Adjusted R-squared: 0.312
    
    TOP 10 PRICE-INCREASING FEATURES:
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Feature</th>
      <th>Coefficient</th>
      <th>P-value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>34</th>
      <td>city_Medina</td>
      <td>631385.74</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>79</th>
      <td>statezip_WA 98039</td>
      <td>631385.74</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>6</th>
      <td>waterfront</td>
      <td>613681.10</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>58</th>
      <td>statezip_WA 98004</td>
      <td>573159.65</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>107</th>
      <td>statezip_WA 98109</td>
      <td>442421.85</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>108</th>
      <td>statezip_WA 98112</td>
      <td>431790.65</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>20</th>
      <td>city_Clyde Hill</td>
      <td>426378.00</td>
      <td>0.03</td>
    </tr>
    <tr>
      <th>129</th>
      <td>statezip_WA 98199</td>
      <td>379149.65</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>74</th>
      <td>statezip_WA 98031</td>
      <td>368166.95</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>103</th>
      <td>statezip_WA 98105</td>
      <td>340959.15</td>
      <td>0.00</td>
    </tr>
  </tbody>
</table>
</div>


    
    TOP 10 PRICE-DECREASING FEATURES:
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Feature</th>
      <th>Coefficient</th>
      <th>P-value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>const</td>
      <td>-632227.32</td>
      <td>0.43</td>
    </tr>
    <tr>
      <th>128</th>
      <td>statezip_WA 98198</td>
      <td>-292927.85</td>
      <td>0.14</td>
    </tr>
    <tr>
      <th>127</th>
      <td>statezip_WA 98188</td>
      <td>-234051.27</td>
      <td>0.13</td>
    </tr>
    <tr>
      <th>126</th>
      <td>statezip_WA 98178</td>
      <td>-199839.85</td>
      <td>0.02</td>
    </tr>
    <tr>
      <th>121</th>
      <td>statezip_WA 98148</td>
      <td>-160039.33</td>
      <td>0.30</td>
    </tr>
    <tr>
      <th>123</th>
      <td>statezip_WA 98166</td>
      <td>-146898.00</td>
      <td>0.24</td>
    </tr>
    <tr>
      <th>124</th>
      <td>statezip_WA 98168</td>
      <td>-130475.29</td>
      <td>0.12</td>
    </tr>
    <tr>
      <th>120</th>
      <td>statezip_WA 98146</td>
      <td>-91023.69</td>
      <td>0.26</td>
    </tr>
    <tr>
      <th>106</th>
      <td>statezip_WA 98108</td>
      <td>-76289.60</td>
      <td>0.39</td>
    </tr>
    <tr>
      <th>5</th>
      <td>floors</td>
      <td>-76088.42</td>
      <td>0.00</td>
    </tr>
  </tbody>
</table>
</div>



```python
# "Matrix Operations Tool"
import numpy as np
def get_matrix(name):
    print("Enter matrix name:")
    r=int(input("Enter number of rows:"))
    c=int(input("Enter number of columns:"))
    print(f"  Enter {r} rows with {c} space-separated numbers each:")
    matrix=[]
    for i in range(r):
        row = list(map(float, input(f"    Row {i+1}: ").split()))
        matrix.append(row)

    return np.array(matrix)
def show(mat, title):
    """Display matrix"""
    print(f"\n{title}:")
    print(mat)
def main():
    print("="*50)
    print("       SIMPLE MATRIX OPERATIONS TOOL")
    print("="*50)
    while True:
        print("\nChoose an option:")
        print("1. Addition")
        print("2. Subtraction")
        print("3. Multiplication")
        print("4. Transpose")
        print("5. Determinant")
        print("6. Exit")

        ch = input("Enter choice: ")

        if ch == '6':
            print("Exiting... Goodbye!")
            break
        # Operations needing two matrices
        if ch in ['1', '2', '3']:
            A = get_matrix("A")
            B = get_matrix("B")
            if ch == '1':     # ADD
                if A.shape != B.shape:
                    print("Error: Matrices must be same size!")
                else:
                    show(A, "Matrix A")
                    show(B, "Matrix B")
                    show(A + B, "A + B")

            elif ch == '2':   # SUBTRACT
                if A.shape != B.shape:
                    print("Error: Matrices must be same size!")
                else:
                    show(A, "Matrix A")
                    show(B, "Matrix B")
                    show(A - B, "A - B")

            elif ch == '3':   # MULTIPLY
                if A.shape[1] != B.shape[0]:
                    print("Error: Columns of A must equal rows of B!")
                else:
                    show(A, "Matrix A")
                    show(B, "Matrix B")
                    show(A @ B, "A × B")

        elif ch == '4':     # TRANSPOSE
            mat = get_matrix("A")
            show(mat, "Original Matrix")
            show(mat.T, "Transpose")

        elif ch == '5':     # DETERMINANT
            mat = get_matrix("A")
            if mat.shape[0] != mat.shape[1]:
                print("Error: Determinant only for square matrices!")
            else:
                show(mat, "Matrix")
                print("Determinant =", np.linalg.det(mat))

        else:
            print("Invalid choice!")

# Run Program
main()

           
```

    ==================================================
           SIMPLE MATRIX OPERATIONS TOOL
    ==================================================
    
    Choose an option:
    1. Addition
    2. Subtraction
    3. Multiplication
    4. Transpose
    5. Determinant
    6. Exit
    

    Enter choice:  1
    

    Enter matrix name:
    

    Enter number of rows: 3
    Enter number of columns: 3
    

      Enter 3 rows with 3 space-separated numbers each:
    

        Row 1:  1
        Row 2:  2
        Row 3:  3
    

    Enter matrix name:
    

    Enter number of rows: 1
    Enter number of columns: 2
    

      Enter 1 rows with 2 space-separated numbers each:
    

        Row 1:  1
    

    Error: Matrices must be same size!
    
    Choose an option:
    1. Addition
    2. Subtraction
    3. Multiplication
    4. Transpose
    5. Determinant
    6. Exit
    

    Enter choice:  11
    

    Invalid choice!
    
    Choose an option:
    1. Addition
    2. Subtraction
    3. Multiplication
    4. Transpose
    5. Determinant
    6. Exit
    

    Enter choice:  1
    

    Enter matrix name:
    

    Enter number of rows: 2
    Enter number of columns: 2
    

      Enter 2 rows with 2 space-separated numbers each:
    

        Row 1:  1
        Row 2:  2
    

    Enter matrix name:
    

    Enter number of rows: 2
    Enter number of columns: 3
    

      Enter 2 rows with 3 space-separated numbers each:
    

        Row 1:  4
        Row 2:  2
    

    
    Matrix A:
    [[1.]
     [2.]]
    
    Matrix B:
    [[4.]
     [2.]]
    
    A + B:
    [[5.]
     [4.]]
    
    Choose an option:
    1. Addition
    2. Subtraction
    3. Multiplication
    4. Transpose
    5. Determinant
    6. Exit
    

    Enter choice:  66
    

    Invalid choice!
    
    Choose an option:
    1. Addition
    2. Subtraction
    3. Multiplication
    4. Transpose
    5. Determinant
    6. Exit
    


```python

```
